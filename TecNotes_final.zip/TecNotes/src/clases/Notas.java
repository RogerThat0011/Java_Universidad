package clases;

/**
 *
 * @author Fernando Cuatro
 */
public class Notas {
 private int id_nota;
 private String titulo;
 private String notas;
 private int id_alumno;

 public int getId_nota() {
  return id_nota;
 }

 public void setId_nota(int id_nota) {
  this.id_nota = id_nota;
 }
 
 public String getTitulo() {
  return titulo;
 }

 public void setTitulo(String titulo) {
  this.titulo = titulo;
 }

 public String getNotas() {
  return notas;
 }

 public void setNotas(String notas) {
  this.notas = notas;
 }

 public int getId_alumno() {
  return id_alumno;
 }

 public void setId_alumno(int id_alumno) {
  this.id_alumno = id_alumno;
 }
 
}
