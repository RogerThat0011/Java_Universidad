package clases;

/**
 *
 * @author Fernando Cuatro
 */
public class Contactos {
 private int id_contacto;
 private String nombre;
 private String apellido;
 private String telefono;
 private String email;
 private String carnet_contacto;
 private String apunte;
 private int id_alumno;

 public int getId_contacto() {
  return id_contacto;
 }

 public void setId_contacto(int id_contacto) {
  this.id_contacto = id_contacto;
 }

 public String getNombre() {
  return nombre;
 }

 public void setNombre(String nombre) {
  this.nombre = nombre;
 }

 public String getApellido() {
  return apellido;
 }

 public void setApellido(String apellido) {
  this.apellido = apellido;
 }

 public String getTelefono() {
  return telefono;
 }

 public void setTelefono(String telefono) {
  this.telefono = telefono;
 }

 public String getEmail() {
  return email;
 }

 public void setEmail(String email) {
  this.email = email;
 }

 public String getCarnet_contacto() {
  return carnet_contacto;
 }

 public void setCarnet_contacto(String carnet_contacto) {
  this.carnet_contacto = carnet_contacto;
 }

 public String getApunte() {
  return apunte;
 }

 public void setApunte(String apunte) {
  this.apunte = apunte;
 }

 public int getId_alumno() {
  return id_alumno;
 }

 public void setId_alumno(int id_alumno) {
  this.id_alumno = id_alumno;
 }
 
 
}
